var URL = "http://br-gateway-service.jx-staging.35.242.252.39.nip.io/br-battle-history-service/";

function AddBattleHistory(history){
    
}

function SaveBattleHistory(){
    
}