var name  = Spark.getData().displayName;
require("UserHelper");
UpdateUserDisplayName(name);