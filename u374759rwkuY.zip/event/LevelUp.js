var exp = Spark.getData().exp;
var level = Spark.getData().level;
require("UserAssestHelper");
UpdateLevel(level, exp);