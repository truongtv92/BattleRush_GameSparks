var coin = Spark.getData().coin;
var gem = Spark.getData().gem;
requireOnce("UserAssestHelper");
UpdateCurrency(coin, gem);