var coin = Spark.getData().coin;
var exp = Spark.getData().exp;
var level = Spark.getData().level;
    require("UserAssestHelper");
    IncreaseCurrency(coin,0);
    AddmoreEXP(exp);